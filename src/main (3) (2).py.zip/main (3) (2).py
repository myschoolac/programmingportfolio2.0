import random
print("Welcome to the number guessing game! Guess a number between 1 and 100.")
test = int(input("Enter input of a number 1 and 100:"))
print(test)
count = 1
randnumber = random.randint(1,100)
while test != randnumber:
  if test > randnumber:
    print("Too high")
  elif test < randnumber:
    print("Too low")
  count += 1
  test = int(input("Enter input of a number 1 and 100:"))
else:
   print("You got it! It took you",count,"tries")


